<!-- START BREADCRUMB -->
<ul class="breadcrumb">
    <li><a href="#">Home</a></li>                    
    <li class="active">Post</li>
</ul>
<!-- END BREADCRUMB -->                       
<div class="page-title">                    
    <h2> New Post</h2>
</div>

<div class="page-content-wrap">

<div class="row">
    <div class="col-md-12">

        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Panel Title</h3>
            </div>
            <div class="panel-body">
                Panel body
            </div>
        </div>

    </div>
</div>

</div>