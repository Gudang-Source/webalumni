
    <!-- jQuery -->
    <script src="<?= base_url('assets/back-end/vendor/jquery/jquery.min.js') ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url('assets/back-end/vendor/bootstrap/js/bootstrap.min.js') ?>"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="<?= base_url('assets/back-end/vendor/scrollreveal/scrollreveal.min.js') ?>"></script>
    <script src="<?= base_url('assets/back-end/vendor/magnific-popup/jquery.magnific-popup.min.js') ?>"></script>

    <!-- Theme JavaScript -->
    <script src="<?= base_url('assets/back-end/js/creative.min.js') ?>"></script>

</body>

</html>
