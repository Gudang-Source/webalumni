<?php echo $header; ?>
<?php echo $contentnya; ?>
<?php echo $footer; ?>
