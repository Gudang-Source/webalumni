		<script type="text/javascript" src="<?= base_url('assets/html/js/plugins/jquery/jquery-ui.min.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/html/js/plugins/jquery/jquery-migrate.min.js') ?>"></script>

        <script type='text/javascript' src="<?= base_url('assets/html/js/plugins/icheck/icheck.min.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js'); ?>"></script>
        
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap-datepicker.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap-timepicker.min.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap-colorpicker.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap-file-input.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/bootstrap/bootstrap-select.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins/tagsinput/jquery.tagsinput.min.js'); ?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/html/js/plugins/dropzone/dropzone.min.js') ?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/html/js/plugins/filetree/jqueryFileTree.js'); ?>"></script>

        <script type="text/javascript" src="<?= base_url('assets/html/js/plugins.js'); ?>"></script>
        <script type="text/javascript" src="<?= base_url('assets/html/js/actions.js'); ?>"></script>

  </body>
</html>
